# Buzzle — каталог подготовленных ассетов

Актуально после одобрения венка revision=32. Это 2D-спрайты с анимацией отдельных частей в одном ракурсе. Новая графика работает в режиме проверки; перенос в основную игру ещё предстоит.

## Пчёлы — 13

| Пчела | Рабочий файл |
|---|---|
| Жужа | [zhuzha-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/zhuzha-reference.png) |
| Пушинка | [pushinka-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/pushinka-reference.png) |
| Шмель Борис | [boris-reference-v2.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/boris-reference-v2.png) |
| Солнышко | [solnyshko-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/solnyshko-reference.png) |
| Лаванда | [lavanda-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/lavanda-reference.png) |
| Клеверина | [klevera-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/klevera-reference.png) |
| Василёк | [vasilek-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/vasilek-reference.png) |
| Мятка | [myatka-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/myatka-reference.png) |
| Искорка | [iskorka-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/iskorka-reference.png) |
| Соня | [sonya-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/sonya-reference.png) |
| Зоркая | [zorkaya-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/zorkaya-reference.png) |
| Марго | [margo-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/margo-reference.png) |
| Ночка | [nochka-reference.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/nochka-reference.png) |

Все рисунки — 1366×1151 с прозрачным фоном. Реализованы крылья, покачивание и моргание; Соня сохраняет закрытые глаза. Цветы, листья, воротники, маска Сони, очки Зоркой и украшения Ночки встроены в рисунки. Маски тела, крыльев и глаз задаются в приложении, отдельные PNG для этих частей не создавались.

Дополнительный рабочий слой: [Жужа без короны](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/zhuzha-base.png). Он используется на уровнях без короны и с головными уборами.

## Аксессуары — 6 нарядов и корона

| Предмет | Рабочий файл | Статус |
|---|---|---|
| Корона уровня 10 | [crown-fitted-v3.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/crown-fitted-v3.png) | Одобрена; посадка revision=20 |
| Шарфик | [scarf-fitted-v4.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/scarf-fitted-v4.png) | Одобрен; левый заворот revision=22 |
| Очки | [glasses-accessory.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/glasses-accessory.png) | Реализованы в прототипе; у Зоркой остаются собственные очки |
| Сумка через плечо | [satchel-left-accessory.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/satchel-left-accessory.png) | Одобрена; положение revision=28, ремень revision=29 |
| Бантик | [bow-accessory.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/bow-accessory.png) | Одобрен; на корпусе, выровнен в revision=31 |
| Венок | [wreath-fitted-v2.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/wreath-fitted-v2.png) | Одобрен; объём revision=31, изгиб revision=32 |
| Берет | [beret-accessory.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/beret-accessory.png) | Одобрен; посадка и усики revision=30 |

Посадка и конечный вид зависят также от кода: PNG венка не включает выравнивание revision=32, PNG бантика — поворот revision=31. Ремень, кольцо сумки, усики поверх берета и поднятый край шарфа — отдельные слои в приложении. Сумка сохраняет игровой ID backpack для совместимости сохранений.

Уровень 5: золотистая окантовка и светлая искра на цветных крыльях, вместе со взмахами. Это программная графика, отдельного PNG нет. Венок и берет заменяют корону уровня 10.

## Иконки — 3 рабочих файла

| Назначение | Файл |
|---|---|
| Иконка приложения | [buzzle-app-icon.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/buzzle-app-icon.png) |
| Передний слой Android adaptive icon | [buzzle-android-icon-foreground.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/buzzle-android-icon-foreground.png) |
| Favicon | [buzzle-favicon.png](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/buzzle-favicon.png) |

Подключены в настройках приложения. Также сохранены [архив иконок](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/buzzle-app-icons.zip), [превью](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/buzzle-icon-preview.png) и [страница проверки](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/icon-preview.html). Заставка запуска и иконка уведомлений пока прежние.

Итого в текущем рабочем наборе: 24 растровых файла — 13 пчёл, дополнительная Жужа без короны, 7 аксессуаров и 3 иконки. Программные слои и метаданные считаются отдельно.

## Концепты предметов — 16 на одном листе

[Лист предметов](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/items-style-draft.png):

1. Мёд.
2. Нектар.
3. Маточное молочко.
4. Семена.
5. Лейка.
6. Лопатка.
7. Бочка.
8. Фонарики.
9. Деревянная сота/коробка.
10. Восковая сота/коробка.
11. Золотая сота/коробка.
12. Королевская сота/коробка.
13. Гриб.
14. Скамейка.
15. Вертушка.
16. Фонтан.

Это концепты. Отдельные прозрачные игровые файлы нового стиля ещё не изготовлены. Требуется упростить грани и проверить в масштабе интерфейса.

## Концепт сада

[Мокап сада](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/garden-style-draft.png): подсолнух, клевер, ростки, объёмная грядка и сочетание с пчёлами. Это единая картинка, а не набор игровых растений.

Для игры ещё нужны росток и стадии семи видов: подсолнух, клевер, лаванда, василёк, мята, лунный мак, золотое солнце. Также предстоит изготовить грядку.

## Архив сделанного

- Предыдущий Борис; старые версии короны, шарфа, венка, рюкзака и сумок сохранены для истории.
- Прежняя Blender-попытка Жужи: [сцена](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/zhuzha-prototype.blend) и 75 WebP-слоёв: 5 ракурсов × 15 слоёв (тело, глаза, два крыла, два золотых крыла, корона, восемь нарядов). Она отклонена по стилю и не является текущим набором.
- Сохранены концепты пчёл, скриншоты карточек, улья, коллекции, аксессуаров и видеозаписи анимаций. Они служат проверке.
- [Исходники рабочего прототипа](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/zhuzha-prototype-source.zip), [актуальные правила стиля и движения](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/BEE_STYLE_AND_MOTION.ru.md).
- [Полный файловый реестр](/Users/oleksandrzabolotnyi/Documents/Codex/2026-10-12/https-github-com-inm1nd-buzzle-https/outputs/ASSET_FILES.csv) перечисляет рабочие файлы, метаданные, дубликаты в outputs, скриншоты и архивные версии. Число строк не равно числу уникальных игровых объектов.

Старые STYLE/TESTING описывают ранние этапы. Актуальный статус приведён здесь и в правилах стиля.

## Что осталось

1. Согласовать ритм взмахов, проверить маски и крепления крыльев у всех персонажей.
2. Сделать наушники и ореол в текущем стиле. Их старые Blender-версии не подходят.
3. Подготовить отдельные ресурсы, инструменты, четыре коробки/соты и декор. Флажки и садовый гном ещё без нового отдельного концепта.
4. Подготовить растения, стадии роста и грядки.
5. Перенести новую графику в основную игру; заменить название рюкзака на сумку во всех языках с сохранением совместимости сохранений.
6. Проверить масштаб, отступы и тени в улье, коллекции, саду, альбоме и всплывающих окнах.
7. Проверить анимацию, паузу/возобновление и нагрузку на настоящем Android-устройстве, оптимизировать размер файлов.

## Почему взмахи отличаются

Три таймера: 62, 71 и 83 мс на цикл — примерно 16,1 / 14,1 / 12,0 циклов в секунду. Выбор зависит от seed % 3, то есть от экземпляра пчелы/его места в превью, а не от вида. Угол одинаковый: ±15°, сжатие по высоте — от 1 до 0,64. Крепления и форма крыльев подогнаны к рисункам, поэтому их движение визуально различается. В веб-просмотре быстрые взмахи могут дополнительно выглядеть разными из-за частоты кадров.

Разница скоростей предусмотрена технически, но отдельный характер полёта видов пока не настроен и не согласован. Рекомендуемый следующий шаг: общий базовый ритм, разные фазы начала, затем небольшая осмысленная поправка для Бориса. В этом запросе скорости не изменены.

